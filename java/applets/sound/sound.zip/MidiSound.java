import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.midi.MidiChannel;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiUnavailableException;
import javax.sound.midi.Synthesizer;

public class MidiSound implements Runnable{
    //vars
    private Synthesizer synth;
    private MidiChannel mchannel;
    private int playNote;
    private Thread myThread;

    //constructor
    public MidiSound(int playNote){
        try {
            synth=MidiSystem.getSynthesizer();
            synth.open();
            mchannel=synth.getChannels()[0];
            this.playNote=playNote;

            myThread=new Thread(this);
            myThread.start();
        } catch (MidiUnavailableException ex) {
            Logger.getLogger(MidiSound.class.getName()).log(Level.SEVERE, null, ex);
        }


     }

    //play sound
    public void run(){
        mchannel.noteOn(playNote,50);
    }
}
